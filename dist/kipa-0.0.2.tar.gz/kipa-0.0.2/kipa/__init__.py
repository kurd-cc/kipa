"""A library to convert Kurdish (Kurmanji) texts to IPA phonetics"""
from .kipa import *
__version__ = 0.1
